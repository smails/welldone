"use strict";
"use strict";

$('.js-open-modal').click(function (e) {
  e.preventDefault();
  $('.modal').hide();
  var modal = e.target.getAttribute('href') != null ? e.target.getAttribute('href') : e.target.parentElement.getAttribute('href');
  $("[data-type=\"".concat(modal, "\"]")).fadeIn();
});
$(window).click(function (e) {
  if (e.target.classList.contains('modal') && e.target.style.display == 'block') {
    $('.modal').fadeOut();
  }
});
"use strict";

var humb = $('.header__burger');
var menu = $('.header__box');

if (humb !== undefined && humb !== null) {
  humb.click(function () {
    humb.toggleClass('open');
    menu.slideToggle();
  });
}

$('.nav__link').click(function (e) {
  e.preventDefault();
  var hash = e.target.getAttribute('href');
  $('html, body').animate({
    scrollTop: $(hash).offset().top - window.innerHeight / 5
  });
  $('.nav__link').removeClass('active');
  $(e.target).addClass('active');

  if (window.innerWidth < 1200 && humb !== undefined && humb !== null) {
    humb.removeClass('open');
    menu.slideUp();
  }
});
"use strict";

$(document).on('change', '.form__file', function (e) {
  var file = e.target.files;
  $(e.target).parent().find('.form__add-file').text(file[0].name);
});
var step = 1;
$('.reg-team__add-pers').click(function () {
  if (step !== 7) {
    $('.reg-team__team').append("<form class=\"form\">\n    <p class=\"form__title\">\u0418\u0433\u0440\u043E\u043A \u2116".concat(step, "\n    </p>\n    <div class=\"form__group\">\n      <p class=\"form__caption\">\u0424\u0430\u043C\u0438\u043B\u0438\u044F\n      </p><input class=\"form__field\" type=\"text\" placeholder=\"\u0412\u0430\u0448\u0430 \u0444\u0430\u043C\u0438\u043B\u0438\u044F\">\n    </div>\n    <div class=\"form__group\">\n      <p class=\"form__caption\">\u0418\u043C\u044F\n      </p><input class=\"form__field\" type=\"text\" placeholder=\"\u0412\u0430\u0448\u0435 \u0438\u043C\u044F\">\n    </div>\n    <div class=\"form__group\">\n      <p class=\"form__caption\">\u0413\u043E\u0440\u043E\u0434\n      </p><input class=\"form__field\" type=\"text\" placeholder=\"\u0418\u0437 \u043A\u0430\u043A\u043E\u0433\u043E \u0432\u044B \u0433\u043E\u0440\u043E\u0434\u0430\">\n    </div>\n    <div class=\"form__group\">\n      <p class=\"form__caption\">E-mail\n      </p><input class=\"form__field\" type=\"email\" placeholder=\"\u0412\u0430\u0448 E-mail\">\n    </div>\n    <div class=\"form__group\">\n      <p class=\"form__caption\">\u041D\u043E\u043C\u0435\u0440 \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0430\n      </p><input class=\"form__field\" type=\"text\" placeholder=\"+7(___) __-__-__\">\n    </div>\n    <button class=\"form__btn btn-register\">\u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C\u0441\u044F\n    </button>\n  </form>"));
    step += 1;
  }
});